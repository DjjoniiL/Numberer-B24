(function () {
  "use strict";

  const appVersion = "Numberer B24 worker v.1.6";
  const settingsOption = "numbererB24Settings";
  const sequenceOption = "numbererB24SequenceState";
  const uniqueFieldName = "UF_CRM_UNIQUE_NUMBER";
  const core = window.NumbererCore;
  const pollMs = 15000;

  let settings = core.normalizeSettings();
  let busy = false;
  let timer = null;

  function callMethod(method, params = {}) {
    return new Promise((resolve, reject) => {
      window.BX24.callMethod(method, params, (result) => {
        if (result.error()) reject(new Error(result.error_description() || result.error()));
        else resolve(result.data());
      });
    });
  }

  async function callList(method, params = {}) {
    const rows = [];
    let start = 0;
    do {
      const data = await new Promise((resolve, reject) => {
        window.BX24.callMethod(method, { ...params, start }, (result) => {
          if (result.error()) reject(new Error(result.error_description() || result.error()));
          else resolve({ data: result.data(), next: result.more() ? result.next() : null });
        });
      });
      rows.push(...(Array.isArray(data.data) ? data.data : []));
      start = data.next;
    } while (start !== null && start !== undefined);
    return rows;
  }

  function optionJson(value, fallback) {
    if (!value) return fallback;
    try {
      return JSON.parse(value);
    } catch {
      return fallback;
    }
  }

  async function loadSettings() {
    const data = await callMethod("app.option.get", { option: settingsOption }).catch(() => null);
    settings = core.normalizeSettings(optionJson(data, core.defaultSettings));
    return settings;
  }

  async function loadSequenceState() {
    const data = await callMethod("app.option.get", { option: sequenceOption }).catch(() => null);
    return optionJson(data, {});
  }

  async function saveSequenceState(sequenceState) {
    await callMethod("app.option.set", { options: { [sequenceOption]: JSON.stringify(sequenceState || {}) } });
  }

  async function uniqueNumberExists(value, exceptDealId) {
    const rows = await callList("crm.deal.list", {
      filter: { [`=${uniqueFieldName}`]: value },
      select: ["ID", uniqueFieldName],
    }).catch(() => []);
    return rows.some((deal) => Number(deal.ID) !== Number(exceptDealId));
  }

  async function generateForDeal(dealId) {
    const deal = await callMethod("crm.deal.get", { id: Number(dealId) });
    const check = core.shouldGenerateForDeal(settings, deal, uniqueFieldName);
    if (!check.ok) return { ok: false, skipped: true, check, dealId };

    let sequenceState = await loadSequenceState();
    let result = null;
    let foundUnique = false;
    for (let attempt = 0; attempt < 25; attempt += 1) {
      result = core.buildNumber(settings, deal, sequenceState, core.dealCategoryId(deal));
      if (settings.generationMode === "sequential") sequenceState[result.key] = result.nextSequence;
      const exists = await uniqueNumberExists(result.value, dealId);
      if (!exists) {
        foundUnique = true;
        break;
      }
      result = null;
    }
    if (!result || !foundUnique) throw new Error("Не удалось подобрать уникальный номер");
    await callMethod("crm.deal.update", { id: Number(dealId), fields: { [uniqueFieldName]: result.value } });
    await saveSequenceState(sequenceState);
    return { ok: true, dealId, number: result.value };
  }

  async function findDealsForConfiguredStages() {
    const deals = [];
    for (const [categoryId, stageId] of Object.entries(settings.stagesByCategory || {})) {
      if (!stageId) continue;
      const rows = await callList("crm.deal.list", {
        order: { ID: "ASC" },
        filter: {
          "=CATEGORY_ID": Number(categoryId),
          "=STAGE_ID": stageId,
          ...(core.dateFilterValue(settings.startDate) ? { ">=DATE_CREATE": core.dateFilterValue(settings.startDate) } : {}),
        },
        select: ["ID", "CATEGORY_ID", "STAGE_ID", "DATE_CREATE", uniqueFieldName, settings.prefixField].filter(Boolean),
      }).catch(() => []);
      deals.push(...rows.filter((deal) => !String(deal[uniqueFieldName] || "").trim() && core.isDealAfterStartDate(settings, deal)));
    }
    return deals.filter((deal, index, list) => list.findIndex((item) => Number(item.ID) === Number(deal.ID)) === index);
  }

  async function processConfiguredStageDeals() {
    const deals = await findDealsForConfiguredStages();
    const limitedDeals = deals.slice(0, 20);
    const results = [];
    for (const deal of limitedDeals) {
      results.push(await generateForDeal(deal.ID));
    }
    return {
      scanned: deals.length,
      processed: limitedDeals.length,
      created: results.filter((item) => item.ok).length,
      skipped: results.filter((item) => item.skipped).length,
      results,
    };
  }

  async function tick() {
    if (busy) return;
    busy = true;
    try {
      await loadSettings();
      const result = await processConfiguredStageDeals();
      localStorage.setItem("numbererB24WorkerLastRun", JSON.stringify({ appVersion, result, at: new Date().toISOString() }));
    } catch (error) {
      localStorage.setItem("numbererB24WorkerLastRun", JSON.stringify({ appVersion, error: error.message, at: new Date().toISOString() }));
    } finally {
      busy = false;
    }
  }

  function boot() {
    if (!window.BX24?.init) return;
    window.BX24.init(async () => {
      await tick();
      timer = window.setInterval(tick, pollMs);
      window.addEventListener("beforeunload", () => {
        if (timer) window.clearInterval(timer);
      });
    });
  }

  boot();
})();
