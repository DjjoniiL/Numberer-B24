(function (root, factory) {
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
  } else {
    root.NumbererCore = factory();
  }
})(typeof globalThis !== "undefined" ? globalThis : window, function () {
  "use strict";

  const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const digitOptions = [3, 4, 5, 6];
  const letterOptions = [2, 3, 4, 5];
  const defaultLetterLength = 2;
  const defaultDigits = 4;
  const defaultStartSequence = 1;

  const defaultSettings = {
    prefixMode: "manual",
    prefixField: "",
    manualPrefix: "NUM",
    prefixSeparator: "_",
    useLetters: true,
    digits: defaultDigits,
    letterLength: defaultLetterLength,
    generationMode: "sequential",
    sharedSequence: false,
    customStartEnabled: false,
    customStartValue: "",
    startDate: "",
    stagesByCategory: {},
  };

  function dateDaysAgo(days, now = new Date()) {
    const date = new Date(now);
    date.setDate(date.getDate() - Number(days || 0));
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}-${month}-${day}`;
  }

  function normalizeSettings(settings) {
    const source = settings && typeof settings === "object" ? settings : {};
    const useLetters = source.useLetters === false || source.useLetters === "false" ? false : true;
    const customStartEnabled = source.customStartEnabled === true || source.customStartEnabled === "on" || source.customStartEnabled === "true";
    const rawCustomStartValue = useLetters ? normalizeStartNumberValue(source.customStartValue) : normalizeNumericStartValue(source.customStartValue);
    const customStartPattern = customStartEnabled ? (useLetters ? parseStartNumberPattern(rawCustomStartValue) : parseNumericStartPattern(rawCustomStartValue, source.digits)) : null;
    const customStartValue = customStartPattern?.value || rawCustomStartValue;
    const digits = customStartPattern?.digits || (digitOptions.includes(Number(source.digits)) ? Number(source.digits) : defaultSettings.digits);
    const letterLength = useLetters ? (customStartPattern?.letterLength || (letterOptions.includes(Number(source.letterLength)) ? Number(source.letterLength) : defaultSettings.letterLength)) : 0;
    return {
      ...defaultSettings,
      ...source,
      prefixMode: ["manual", "field", "none"].includes(source.prefixMode) ? source.prefixMode : "manual",
      prefixField: String(source.prefixField || ""),
      manualPrefix: String(source.manualPrefix || ""),
      prefixSeparator: source.prefixSeparator === "-" ? "-" : (source.prefixSeparator === "" || source.prefixSeparator === "none" ? "" : "_"),
      useLetters,
      digits,
      letterLength,
      generationMode: customStartEnabled ? "sequential" : (source.generationMode === "random" ? "random" : "sequential"),
      sharedSequence: source.sharedSequence === true || source.sharedSequence === "on" || source.sharedSequence === "true",
      customStartEnabled,
      customStartValue,
      startDate: normalizeDateOnly(source.startDate),
      stagesByCategory: source.stagesByCategory && typeof source.stagesByCategory === "object" ? source.stagesByCategory : {},
    };
  }

  function normalizeDateOnly(value) {
    const text = String(value || "").trim();
    const match = text.match(/^(\d{4})-(\d{2})-(\d{2})/);
    if (!match) return "";
    const date = new Date(`${match[1]}-${match[2]}-${match[3]}T00:00:00`);
    return Number.isNaN(date.getTime()) ? "" : `${match[1]}-${match[2]}-${match[3]}`;
  }

  function dateFilterValue(value) {
    const date = normalizeDateOnly(value);
    return date ? `${date}T00:00:00` : "";
  }

  function cleanPrefix(value) {
    return String(value || "")
      .trim()
      .replace(/\s+/g, "-")
      .replace(/[^0-9A-Za-zА-Яа-яЁё_-]/g, "")
      .slice(0, 32);
  }

  function normalizeFieldKey(value) {
    return String(value || "").replace(/[^0-9A-Za-z]/g, "").toUpperCase();
  }

  function fieldValue(record, fieldName) {
    if (!record || !fieldName) return undefined;
    if (Object.prototype.hasOwnProperty.call(record, fieldName)) return record[fieldName];
    const target = normalizeFieldKey(fieldName);
    const found = Object.keys(record).find((key) => normalizeFieldKey(key) === target);
    return found ? record[found] : undefined;
  }

  function pow26(length) {
    return Math.pow(26, Number(length) || 0);
  }

  function numberCapacity(digits) {
    return Math.pow(10, Number(digits) || 0);
  }

  function sequenceCapacity(digits, letterLength) {
    return pow26(letterLength) * numberCapacity(digits);
  }

  function normalizeSequenceValue(value, digits, letterLength) {
    const numericCapacity = numberCapacity(digits);
    const capacity = sequenceCapacity(digits, letterLength);
    let sequence = ((Number(value) || 0) % capacity + capacity) % capacity;
    if (sequence < defaultStartSequence) sequence = defaultStartSequence;
    if (sequence % numericCapacity === 0) {
      sequence = (sequence + 1) % capacity;
      if (sequence < defaultStartSequence) sequence = defaultStartSequence;
    }
    return sequence;
  }

  function nextSequenceValue(value, digits, letterLength) {
    return normalizeSequenceValue(Number(value || 0) + 1, digits, letterLength);
  }

  function formatNumber(value, digits) {
    const size = numberCapacity(digits);
    const normalized = ((Number(value) || 0) % size + size) % size;
    return String(normalized).padStart(Number(digits), "0");
  }

  function lettersFromIndex(index, length) {
    const total = pow26(length);
    let value = ((Number(index) || 0) % total + total) % total;
    let out = "";
    for (let i = 0; i < length; i += 1) {
      const code = value % 26;
      out = alphabet[code] + out;
      value = Math.floor(value / 26);
    }
    return out;
  }

  function lettersToIndex(letters) {
    const value = String(letters || "").toUpperCase();
    let index = 0;
    for (let i = 0; i < value.length; i += 1) {
      const code = alphabet.indexOf(value[i]);
      if (code < 0) return null;
      index = index * 26 + code;
    }
    return index;
  }

  function normalizeStartNumberValue(value) {
    return String(value || "").trim().toUpperCase().replace(/[^0-9A-Z]/g, "");
  }

  function normalizeNumericStartValue(value) {
    return String(value || "").trim().replace(/\D/g, "");
  }

  function parseNumericStartPattern(value, configuredDigits) {
    const normalized = normalizeNumericStartValue(value);
    if (!normalized) return null;
    const digits = digitOptions.includes(Number(configuredDigits))
      ? Number(configuredDigits)
      : (digitOptions.includes(normalized.length) ? normalized.length : defaultDigits);
    const number = String(Math.max(defaultStartSequence, Number(normalized) || 0)).padStart(digits, "0");
    return {
      value: number,
      letters: "",
      number,
      letterLength: 0,
      digits,
    };
  }

  function parseStartNumberPattern(value) {
    const normalized = normalizeStartNumberValue(value);
    const numericOnly = normalized.match(/^\d+$/);
    const numericStart = numericOnly && Number(normalized) < defaultStartSequence ? String(defaultStartSequence) : normalized;
    const valueWithLetters = numericOnly
      ? `${"A".repeat(defaultLetterLength)}${numericStart.padStart(defaultDigits, "0")}`
      : normalized;
    const match = valueWithLetters.match(/^([A-Z]+)(\d+)$/);
    if (!match) return null;
    const letterLength = match[1].length;
    const digits = match[2].length;
    if (!letterOptions.includes(letterLength) || !digitOptions.includes(digits)) return null;
    const number = String(Math.max(defaultStartSequence, Number(match[2]) || 0)).padStart(digits, "0");
    return {
      value: `${match[1]}${number}`,
      letters: match[1],
      number,
      letterLength,
      digits,
    };
  }

  function customStartSequence(settings) {
    const normalized = normalizeSettings({ ...settings, customStartEnabled: false });
    if (!settings?.customStartEnabled) return defaultStartSequence;
    const pattern = normalized.useLetters
      ? parseStartNumberPattern(settings.customStartValue)
      : parseNumericStartPattern(settings.customStartValue, normalized.digits);
    if (!pattern) return defaultStartSequence;
    const letterIndex = normalized.useLetters ? lettersToIndex(pattern.letters) : 0;
    if (letterIndex === null) return defaultStartSequence;
    const sequence = letterIndex * numberCapacity(normalized.digits) + Number(pattern.number);
    return normalizeSequenceValue(sequence, normalized.digits, normalized.letterLength);
  }

  function randomInt(max) {
    return Math.floor(Math.random() * Math.max(1, Number(max) || 1));
  }

  function randomLetters(length) {
    let out = "";
    for (let i = 0; i < length; i += 1) out += alphabet[randomInt(26)];
    return out;
  }

  function sequenceKey(settings, categoryId) {
    const normalized = normalizeSettings(settings);
    const scopeKey = normalized.sharedSequence ? "all" : String(categoryId ?? "0");
    const prefixKey = normalized.prefixMode === "none"
      ? "none"
      : (normalized.prefixMode === "field" ? `field:${normalized.prefixField}` : `manual:${cleanPrefix(normalized.manualPrefix)}`);
    const separatorKey = normalized.prefixSeparator || "none";
    const startKey = normalized.customStartEnabled ? `start:${normalized.customStartValue}` : "start:default";
    if (!normalized.sharedSequence && normalized.prefixSeparator === "_") {
      return [scopeKey, prefixKey, normalized.digits, normalized.letterLength, startKey].join("|");
    }
    return [scopeKey, prefixKey, separatorKey, normalized.digits, normalized.letterLength, startKey].join("|");
  }

  function buildNumber(settings, deal, sequenceState, categoryId) {
    const normalized = normalizeSettings(settings);
    const prefixSource = normalized.prefixMode === "none"
      ? ""
      : (normalized.prefixMode === "field" ? fieldValue(deal, normalized.prefixField) : normalized.manualPrefix);
    const prefix = cleanPrefix(prefixSource);
    const key = sequenceKey(normalized, categoryId);
    const state = sequenceState && typeof sequenceState === "object" ? sequenceState : {};
    const letterCapacity = pow26(normalized.letterLength);
    const numericCapacity = numberCapacity(normalized.digits);
    const rawSequenceCapacity = sequenceCapacity(normalized.digits, normalized.letterLength);
    const configuredStart = customStartSequence(normalized);
    const current = normalizeSequenceValue(state[key] === undefined || state[key] === null ? configuredStart : state[key], normalized.digits, normalized.letterLength);

    let letters;
    let number;
    let nextSequence = current;
    if (normalized.generationMode === "random") {
      letters = randomLetters(normalized.letterLength);
      number = formatNumber(randomInt(numericCapacity - 1) + 1, normalized.digits);
    } else {
      letters = lettersFromIndex(Math.floor(current / numericCapacity), normalized.letterLength);
      number = formatNumber(current % numericCapacity, normalized.digits);
      nextSequence = nextSequenceValue(current, normalized.digits, normalized.letterLength);
    }

    const separator = prefix && normalized.prefixSeparator && !/[_-]$/.test(prefix) ? normalized.prefixSeparator : "";
    return {
      value: `${prefix}${separator}${letters}${number}`,
      prefix,
      letters,
      number,
      key,
      nextSequence,
      capacity: rawSequenceCapacity - letterCapacity,
    };
  }

  function prefixFieldProblem(settings, deal) {
    const normalized = normalizeSettings(settings);
    if (normalized.prefixMode !== "field") return null;
    if (!normalized.prefixField) return { reason: "prefix-field-not-selected" };
    const rawValue = fieldValue(deal, normalized.prefixField);
    if (cleanPrefix(rawValue)) return null;
    return {
      reason: "prefix-field-empty",
      field: normalized.prefixField,
    };
  }

  function helpText(digits, letterLength) {
    if (Number(letterLength) === 0) {
      const digitCount = numberCapacity(digits) - 1;
      return {
        letterCount: 1,
        digitCount,
        total: digitCount,
        text: `Буквенная часть выключена. Формат из ${digits} цифр дает ${digitCount.toLocaleString("ru-RU")} числовых вариантов от ${String(1).padStart(digits, "0")} до ${"9".repeat(digits)}.`,
      };
    }
    const letterCount = pow26(letterLength);
    const digitCount = numberCapacity(digits) - 1;
    const total = letterCount * digitCount;
    return {
      letterCount,
      digitCount,
      total,
      text: `В латинском алфавите 26 букв. Формат ${"A".repeat(letterLength)} дает 26^${letterLength} = ${letterCount.toLocaleString("ru-RU")} буквенных вариантов. Формат из ${digits} цифр дает ${digitCount.toLocaleString("ru-RU")} числовых вариантов от ${String(1).padStart(digits, "0")} до ${"9".repeat(digits)}. Вместе это до ${total.toLocaleString("ru-RU")} комбинаций на один префикс.`,
    };
  }

  function uniqueNumberFilter(settings, value, categoryId, uniqueField = "UF_CRM_UNIQUE_NUMBER") {
    const normalized = normalizeSettings(settings);
    const filter = { [`=${uniqueField}`]: value };
    if (!normalized.sharedSequence) filter["=CATEGORY_ID"] = dealCategoryId({ CATEGORY_ID: categoryId });
    return filter;
  }

  function dealCategoryId(deal) {
    const raw = deal?.CATEGORY_ID ?? deal?.categoryId ?? 0;
    const value = Number(raw);
    return Number.isFinite(value) ? value : 0;
  }

  function dealCreatedAt(deal) {
    const raw = deal?.DATE_CREATE ?? deal?.dateCreate ?? "";
    const date = new Date(raw);
    return Number.isNaN(date.getTime()) ? null : date;
  }

  function isDealAfterStartDate(settings, deal) {
    const normalized = normalizeSettings(settings);
    const startDate = dateFilterValue(normalized.startDate);
    if (!startDate) return true;
    const createdAt = dealCreatedAt(deal);
    if (!createdAt) return false;
    return createdAt.getTime() >= new Date(startDate).getTime();
  }

  function shouldGenerateForDeal(settings, deal, uniqueField) {
    const normalized = normalizeSettings(settings);
    const categoryId = dealCategoryId(deal);
    const targetStage = normalized.stagesByCategory[String(categoryId)];
    if (!targetStage) return { ok: false, reason: "stage-not-configured", categoryId };
    if (String(deal?.STAGE_ID || "") !== String(targetStage)) return { ok: false, reason: "stage-mismatch", categoryId, targetStage };
    if (!isDealAfterStartDate(normalized, deal)) return { ok: false, reason: "created-before-start-date", categoryId, targetStage, startDate: normalized.startDate };
    if (uniqueField && String(fieldValue(deal, uniqueField) || "").trim()) return { ok: false, reason: "already-numbered", categoryId, targetStage };
    return { ok: true, categoryId, targetStage };
  }

  return {
    alphabet,
    digitOptions,
    letterOptions,
    defaultSettings,
    dateDaysAgo,
    normalizeSettings,
    normalizeDateOnly,
    dateFilterValue,
    cleanPrefix,
    normalizeFieldKey,
    fieldValue,
    prefixFieldProblem,
    pow26,
    numberCapacity,
    normalizeSequenceValue,
    formatNumber,
    lettersFromIndex,
    lettersToIndex,
    normalizeStartNumberValue,
    normalizeNumericStartValue,
    parseStartNumberPattern,
    parseNumericStartPattern,
    customStartSequence,
    randomLetters,
    sequenceKey,
    buildNumber,
    helpText,
    dealCategoryId,
    dealCreatedAt,
    isDealAfterStartDate,
    shouldGenerateForDeal,
    uniqueNumberFilter,
  };
});
